import javax.swing.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        int opcion, opcionCuenta;
        double montoDeposito, retiro;
        CuentaBancaria cuenta = new CuentaBancaria(0);
        CuentaDeAhorros cuentaDeAhorros = new CuentaDeAhorros(0, 0.006);
        CDT cdt = null;

        do {
            opcion = Integer.parseInt(JOptionPane.showInputDialog("""
                    Menu \

                    1. Visualizar saldo en cuenta \

                    2.Visualizar monto en CDT \

                    3.Visualizar montos totales \

                    4. Visualizar interes generado en CDT \

                    5. Invertir un monto de dinero en un CDT \

                    6. Cerrar la inversin en CDT.\

                    7. Hacer un deposito.\

                    8. Hacer un retiro.\

                    9. Avanzar un mes a la simulacion
                    10. Salir"""));
        switch (opcion) {
            case 1:
                opcionCuenta = Integer.parseInt(JOptionPane.showInputDialog("Que cuenta desea visualizar? 1 - Ahorros, 2 - Corriente: "));
                switch (opcionCuenta) {
                    case 1:
                        JOptionPane.showMessageDialog(null, "El monto de la cuenta corriente es " + cuenta.getSaldo());
                        break;
                    case 2:
                        JOptionPane.showMessageDialog(null, "El monto de la cuenta de ahorros es " + cuentaDeAhorros.getSaldo());
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Esa no es una opcion valida");
                        break;
                }
                break;
            case 2:
                if (cdt != null) {
                    JOptionPane.showMessageDialog(null, "El monto del CDT es " + cdt.getSaldo());
                } else {
                    JOptionPane.showMessageDialog(null, "No tiene un CDT abierto.");
                }
                break;
            case 3:
                if (cdt != null) {
                    JOptionPane.showMessageDialog(null, "El monto total de sus cuentas es: " + (cuenta.getSaldo() + cuentaDeAhorros.getSaldo() + cdt.getSaldo()));
                } else {
                    JOptionPane.showMessageDialog(null, "El monto total de sus cuentas es: " + (cuenta.getSaldo() + cuentaDeAhorros.getSaldo()));
                }
                break;
            case 4:
                if (cdt != null) {
                    JOptionPane.showMessageDialog(null, "Su interes generado es de: " + cdt.calcularInteres());
                } else {
                    JOptionPane.showMessageDialog(null, "No tiene un CDT abierto.");
                }
            case 5:
                double cuantoInteres, cuantoInversion;
                cuantoInversion = Double.parseDouble(JOptionPane.showInputDialog("Cuanto desea invertir en el CDT? "));
                cuantoInteres = Double.parseDouble(JOptionPane.showInputDialog("Cuanto desea que sea su interes?"));
                cdt = new CDT(cuantoInversion, cuantoInteres);
                break;
            case 6:
                if (cdt != null) {
                    cdt.cerrarCuenta(cuenta);
                } else {
                    JOptionPane.showMessageDialog(null, "No tiene un CDT abierto.");
                }
                break;
            case 7:
                opcionCuenta = Integer.parseInt(JOptionPane.showInputDialog("A que cuenta desea depositar? 1 - Ahorros, 2 - Corriente: "));
                montoDeposito = Double.parseDouble(JOptionPane.showInputDialog("Cuanto desea depositar? "));
                switch (opcionCuenta) {
                    case 1:
                        cuenta.hacerDeposito(montoDeposito);
                        break;
                    case 2:
                        cuentaDeAhorros.hacerDeposito(montoDeposito);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Esa no es una opcion valida");
                        break;
                }

                break;
            case 8:
                opcionCuenta = Integer.parseInt(JOptionPane.showInputDialog("A que cuenta desea hacer el retiro? 1 - Ahorros, 2 - Corriente: "));
                retiro = Double.parseDouble(JOptionPane.showInputDialog("Cuanto desea retirar? "));
                switch (opcionCuenta) {
                    case 1:
                        cuenta.hacerRetiro(retiro);
                        break;
                    case 2:
                        cuentaDeAhorros.hacerRetiro(retiro);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Esa no es una opcion valida");
                        break;
                }
                    case 9:
                        JOptionPane.showMessageDialog(null, "Se ha avanzado un mes. Sus cuentas han generado interes.");
                        if (cdt != null) {
                            cdt.depositarInteresEnCuenta();
                            }
                        cuentaDeAhorros.depositarInteresEnCuenta();
                        break;
                    case 10:
                        System.exit(0);
            }
        } while (opcion != 10);


    }
}