public class CDT extends CuentaDeAhorros{
    public CDT ( double montoInicial, double interes){
        super (montoInicial, interes);
    }
    public void cerrarCuenta(CuentaBancaria cuentaBancaria){
        double saldoCDT = getSaldo();
        double interesCDT = calcularInteres();
        cuentaBancaria.hacerDeposito(saldoCDT+interesCDT);
        setSaldo(0);
    }
}
