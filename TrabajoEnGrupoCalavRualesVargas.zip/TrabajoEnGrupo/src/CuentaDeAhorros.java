public class CuentaDeAhorros extends CuentaBancaria{
       private double interes;
       public CuentaDeAhorros(double montoInicial, double interes){
              super(montoInicial);
              this.interes = interes;
       }

       public double getInteres(){
              return interes;
       }
       public void setInteres(double interes){
              this.interes = interes;
       }

       public double calcularInteres(){
              double saldoActual = getSaldo();
              return saldoActual*interes;
       }

       public void depositarInteresEnCuenta(){
              hacerDeposito(calcularInteres());
       }

}
