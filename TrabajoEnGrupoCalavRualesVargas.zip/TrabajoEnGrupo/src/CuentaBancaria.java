import javax.swing.*;

public class CuentaBancaria {
    private double saldo;

    public CuentaBancaria(double montoInicial) {
        this.saldo = montoInicial;
    }

    public double getSaldo (){
        return this.saldo;
    }
    public void setSaldo(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    public void hacerDeposito(double deposito){
        this.saldo += deposito;
    }
    public void hacerRetiro(double retiro){
        if (this.saldo >= retiro){
            this.saldo -= retiro;
        } else {
            JOptionPane.showMessageDialog(null, "Saldo Insuficiente para realizar la operacion.");
        }
    }

}
