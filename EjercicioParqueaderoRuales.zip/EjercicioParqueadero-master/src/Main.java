import javax.swing.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int op, ec, sac_car, nuev_tar;
        String placa;
        Scanner sc = new Scanner(System.in);
        Parqueadero parqueadero = new Parqueadero();
        do {
            do {;
                op = Integer.parseInt(JOptionPane.showInputDialog("\nMenú: " +
                        "\n1. Ingresar un carro " +
                        "\n2. Dar salida a un carro " +
                        "\n3. Informar los ingresos del parqueadero " +
                        "\n4. Consultar la cantidad de puestos disponibles " +
                        "\n5. Avanzar el reloj del parqueadero " +
                        "\n6. Cambiar la tarifa del parqueadero " +
                        "\n7. Mostrar resultado metodo 1" +
                        "\n8. Mostrar resultado metodo 2" +
                        "\n9. Salir" +
                        "\nLa hora actual es: " + parqueadero.darHoraActual() +
                        "\nSeleccione una opción: "));
                if (op > 9 || op < 1) {
                    JOptionPane.showMessageDialog(null, "Por favor ingrese un numero valido.");
                }
            } while (op > 9 || op < 1);
                switch (op){
                    case 1:
                        if (parqueadero.estaAbierto()) {
                            placa = JOptionPane.showInputDialog(null, "Ingrese un numero del placa");
                            ec = parqueadero.entrarCarro(placa);
                            if (ec > -1) {
                                JOptionPane.showMessageDialog(null, "El carro con la placa: " + placa + " fue ingresado al parqueadero #" + ec);
                            }
                        }
                        break;
                    case 2:
                        if (parqueadero.estaAbierto()) {
                            placa = JOptionPane.showInputDialog(null, "Ingrese la placa del parqueadero");
                            sac_car = parqueadero.sacarCarro(placa);
                            if (sac_car > -1) {
                                JOptionPane.showMessageDialog(null, "Monto a pagar: " + sac_car);
                            }
                        }
                        break;
                    case 3:
                        if (parqueadero.carros_total() > 0 && parqueadero.carros_total() < 2) {
                            JOptionPane.showMessageDialog(null,"Al momento hay " + parqueadero.carros_total() + " carro en el parqueadero.");
                        } else if (parqueadero.carros_total() > 1){
                            JOptionPane.showMessageDialog(null, "Al momento hay " + parqueadero.carros_total() + " carros en el parqueadero.");
                        } else {
                            JOptionPane.showMessageDialog(null, "No hay carros en el parqueadero.");
                        }
                        break;
                    case 4:
                        JOptionPane.showMessageDialog(null, "Actualmente hay " +  parqueadero.calcularPuestosLibres() + " disponibles.");
                        break;
                    case 5:
                        parqueadero.avanzarHora();
                        JOptionPane.showMessageDialog(null, "La hora actual es: " +parqueadero.darHoraActual());
                        JOptionPane.showMessageDialog(null, "Actualmente se han avanzando: " + parqueadero.horas_aniadidas);
                        break;
                    case 6:
                        nuev_tar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el valor de la tarifa nueva: "));
                        parqueadero.cambiarTarifa(nuev_tar);
                        JOptionPane.showMessageDialog(null, "El tarifa nueva: " + nuev_tar);
                        break;
                    case 7:
                        JOptionPane.showMessageDialog(null, parqueadero.metodo1());
                        break;
                    case 8:
                        JOptionPane.showMessageDialog(null, parqueadero.metodo2());
                        break;
                    case 9:
                        System.exit(0);
                        break;
                }
        } while (op!=9);

    }
}